document.addEventListener('DOMContentLoaded', () => {
    const grid = document.querySelector('.grid');
    const scoreDisplay = document.getElementById('score');
    const width = 8;
    const squares = [];
    let score = 0;

    // Using Emojis as Gems for easy web rendering
    const gemColors = ['🔴', '🔵', '🟢', '🟡', '🟣', '🟠'];

    // Create Board
    function createBoard() {
        for (let i = 0; i < width * width; i++) {
            const square = document.createElement('div');
            square.setAttribute('draggable', true);
            square.setAttribute('id', i);
            let randomColor = Math.floor(Math.random() * gemColors.length);
            square.innerHTML = gemColors[randomColor];
            grid.appendChild(square);
            squares.push(square);
        }
    }
    createBoard();

    let colorBeingDragged;
    let colorBeingReplaced;
    let squareIdBeingDragged;
    let squareIdBeingReplaced;

    // Dragging events
    squares.forEach(square => square.addEventListener('dragstart', dragStart));
    squares.forEach(square => square.addEventListener('dragend', dragEnd));
    squares.forEach(square => square.addEventListener('dragover', dragOver));
    squares.forEach(square => square.addEventListener('dragenter', dragEnter));
    squares.forEach(square => square.addEventListener('dragleave', dragLeave));
    squares.forEach(square => square.addEventListener('drop', dragDrop));

    function dragStart() {
        colorBeingDragged = this.innerHTML;
        squareIdBeingDragged = parseInt(this.id);
    }

    function dragOver(e) { e.preventDefault(); }
    function dragEnter(e) { e.preventDefault(); }
    function dragLeave() {}

    function dragDrop() {
        colorBeingReplaced = this.innerHTML;
        squareIdBeingReplaced = parseInt(this.id);
        this.innerHTML = colorBeingDragged;
        squares[squareIdBeingDragged].innerHTML = colorBeingReplaced;
    }

    function dragEnd() {
        // Define valid moves (left, right, up, down)
        let validMoves = [
            squareIdBeingDragged - 1,
            squareIdBeingDragged - width,
            squareIdBeingDragged + 1,
            squareIdBeingDragged + width
        ];
        
        let validMove = validMoves.includes(squareIdBeingReplaced);

        if (squareIdBeingReplaced && validMove) {
            squareIdBeingReplaced = null;
        } else if (squareIdBeingReplaced && !validMove) {
            squares[squareIdBeingReplaced].innerHTML = colorBeingReplaced;
            squares[squareIdBeingDragged].innerHTML = colorBeingDragged;
        } else {
            squares[squareIdBeingDragged].innerHTML = colorBeingDragged;
        }
    }

    // Checking for matches
    function checkRowForThree() {
        for (let i = 0; i < 61; i++) {
            let rowOfThree = [i, i+1, i+2];
            let decidedColor = squares[i].innerHTML;
            const isBlank = squares[i].innerHTML === '';
            const notValid = [6, 7, 14, 15, 22, 23, 30, 31, 38, 39, 46, 47, 54, 55];
            if (notValid.includes(i)) continue;

            if (rowOfThree.every(index => squares[index].innerHTML === decidedColor && !isBlank)) {
                score += 3;
                scoreDisplay.innerHTML = score;
                rowOfThree.forEach(index => {
                    squares[index].innerHTML = '';
                });
            }
        }
    }

    function checkColumnForThree() {
        for (let i = 0; i < 47; i++) {
            let columnOfThree = [i, i+width, i+width*2];
            let decidedColor = squares[i].innerHTML;
            const isBlank = squares[i].innerHTML === '';

            if (columnOfThree.every(index => squares[index].innerHTML === decidedColor && !isBlank)) {
                score += 3;
                scoreDisplay.innerHTML = score;
                columnOfThree.forEach(index => {
                    squares[index].innerHTML = '';
                });
            }
        }
    }

    // Drop gems down when matches are cleared
    function moveDown() {
        for (let i = 0; i < 56; i++) {
            if (squares[i + width].innerHTML === '') {
                squares[i + width].innerHTML = squares[i].innerHTML;
                squares[i].innerHTML = '';
            }
        }
        // Refill first row
        for(let i = 0; i < 8; i++) {
            if(squares[i].innerHTML === '') {
                let randomColor = Math.floor(Math.random() * gemColors.length);
                squares[i].innerHTML = gemColors[randomColor];
            }
        }
    }

    // Game Loop
    window.setInterval(function() {
        checkRowForThree();
        checkColumnForThree();
        moveDown();
    }, 100);
});