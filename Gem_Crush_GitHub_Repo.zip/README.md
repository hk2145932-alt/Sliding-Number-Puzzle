# Gem Crush: Match 3 Puzzle

Welcome to the **Gem Crush** repository! This is a web-based HTML5 Match-3 puzzle game built entirely with HTML, CSS, and Vanilla JavaScript. 

## 🎮 How to Play
- Open `index.html` in any web browser.
- Click and drag a gem to swap it with an adjacent gem (Up, Down, Left, Right).
- Match 3 or more gems of the same color to crush them and score points!

## 🚀 How to Host on GitHub Pages (Free)
1. Upload these files to a new GitHub repository.
2. Go to your repository **Settings**.
3. Navigate to **Pages** (under the "Code and automation" section).
4. Under **Source**, select the `main` branch and save.
5. GitHub will provide you with a live link (e.g., `https://yourusername.github.io/gem-crush`). Share it with the world!

## 🛠 Tech Stack
- HTML5
- CSS3
- Vanilla JavaScript (No frameworks needed!)
